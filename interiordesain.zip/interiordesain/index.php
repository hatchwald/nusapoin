<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Room Interior's</title>

        <link rel="shortcut icon" href="img/lg.png">
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/agency.css" rel="stylesheet">
        <!-- <link rel="stylesheet" href="css/jquery.fancybox.css"> -->
        <link rel="stylesheet" href="css/style.css">
        <!-- Custom Fonts -->
        <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
        <link href="http://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet" type="text/css">
        <link href="http://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic" rel="stylesheet" type="text/css">
        <link href="http://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  border: none;
  outline: none;
  background-color: #4D719A;
  cursor: pointer;
  padding: 15px;
  border-radius: 10px;
}

#myBtn:hover {
  background-color: #555;
}
</style>
    </head>

    <body id="page-top" class="index">

           <a href="#page-top" onclick="topFunction()" id="myBtn" class="page-scroll" > <i class="fa fa-chevron-up" aria-hidden="true"></i></a>

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-fixed-top navbar-shrink">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand page-scroll" href="#page-top">Interior's</a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="hidden">
                            <a href="#page-top"></a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#services">Services</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#about">About</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#galeri">Portfolio</a>
                        </li>
                        <li class="active">
                            <a class="page-scroll" href="#contact">Notify</a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>

        <!-- Header -->
        <header>
            <div class="container">
                <div class="intro-text">
                    <div class="intro-heading">design interior</div>
                    <div class="intro-lead-in">membuat setiap ruang rumah anda menjadi istimewa</div>
                    <a href="#services" class="page-scroll btn btn-xl">Dapatkan Segera</a>
                </div>
            </div>
        </header>

        <!-- Services Section -->
        <section id="services">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2 class="section-heading">Services</h2>
                        <h3 class="section-subheading text-muted">Layanan yang dapat kami berikan</h3>
                    </div>
                </div>
                <div class="row text-center">

                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fa fa-circle fa-stack-2x text-primary"></i>
                            <i class="fa fa-rocket fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="service-heading">Fast Instalasi</h4>
                        <p class="text-muted">Proses instalasi yang cepat dan tepat karena dikerjakan oleh para ahli nya.</p>
                    </div>
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fa fa-circle fa-stack-2x text-primary"></i>
                            <i class="fa fa-thumbs-up fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="service-heading">Best Quality</h4>
                        <p class="text-muted">Bahan interior kami memiliki kualitas yang terbaik dari yang terbaik.</p>
                    </div>


                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fa fa-circle fa-stack-2x text-primary"></i>
                            <i class="fa fa-phone fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="service-heading">24 H Support</h4>
                        <p class="text-muted">Kami siap melayani setiap kebutuhan anda 24 jam </p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Tentang Section -->
        <section id="about" class="bg-light-gray">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2 class="section-heading">About Us</h2>
                        <img src="img/lg.png" alt=""><br><br>
                        <div class="section-subheading text-muted">Perusahaan kami adalah perusahaan yang bergerak dibidang jasa instalasi interior ruangan yang telah berpengalaman dalam bidang ini , dan mempunyai kualitas dijamin terbaik.</div>
                    </div>
                </div>

            </div>
        </section>
        <!-- portofolio section -->
        <section id="galeri" class="bg-light-brown">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2 class="section-heading">Portfolio</h2>
                        <h3 class="section-subheading text-muted">ini adalah hasil contoh dari pekerjaan kami.</h3>
                    </div>

                    <ul class="gallery_agile">
    				<!-- <li>
    					<div class="w3_agile_portfolio_grid">
    						<a href="images/10.jpg">
    						<img src="images/10.jpg" alt=" " class="img-responsive" />
    						<div class="w3layouts_news_grid_pos">
    							<div class="wthree_text"><h3>Classy <span>Decor</span></h3></div>
    						</div>
    					</a>
    					</div>
    				</li> -->
    				<?php
            for ($i=1; $i <4 ; $i++) {
              echo "<li>
      					<div class='w3_agile_portfolio_grid'>
      						<a href='img/gale/$i.jpg'>
      						<img src='img/gale/$i.jpg' alt='' class='img-responsive' />
      						<div class='w3layouts_news_grid_pos'>
      							<div class='wthree_text'><h3> <span></span></h3></div>
      						</div>
      					</a>
      					</div>
      				</li>";
            }
             ?>

    			</ul>

                </div>
                <br>
                <div class="" align="center">
                  <a type="button" class="btn btn-xl" href="gallery.php">Lainnya >></a>
                </div>
                </div>

            </div>
        </section>
         <!-- Contact Section -->
        <section id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2 class="section-heading">Notify</h2>
                        <h3 class="section-subheading text-muted">Dapatkan beberapa tawaran dari kami dengan cepat.</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <form action="#" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                            <div class="row">
                                <div class="col-md-6 col-md-offset-3">

                                    <div class="form-group">
                                        <input type="email" name="EMAIL" class="form-control" placeholder="Your Email" id="email" required="" data-validation-required-message="Please enter your email address.">
                                        <p class="help-block text-danger"></p>
                                    </div>

                                </div>
                                <div class="clearfix"></div>
                                <div class="col-lg-12 text-center">
                                    <div id="success"></div>
                                    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                    <div style="position: absolute; left: -5000px;"><input type="text" name="b_3ab01c04621448c868bd23c40_6aad136474" tabindex="-1" value=""></div>
                                    <button type="submit" class="btn btn-xl">Notify Me</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <span class="copyright">Created By F.R VEA</span>
                    </div>
                    <div class="col-md-4">
                        <ul class="list-inline social-buttons">
                            <li><a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <ul class="list-inline quicklinks">
                            <li>Jl.Graha golf IV No.9
                            </li>
                            <li>Tirtomoyo-Pakis,Malang
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>


        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- <script src="js/jquery.fancybox.js"></script> -->
        <script src="js/jquery.chocolat.js "></script>
	       <link rel="stylesheet " href="css/chocolat.css " type="text/css " media="screen ">
	        <!--light-box-files -->
        	<script type="text/javascript ">
        		$(function () {
        			$('.w3_agile_portfolio_grid a').Chocolat();
        		});
        	</script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.js"></script>

        <!-- Plugin JavaScript -->
        <script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
// function topFunction() {
//     document.body.scrollTop = 0;
//     document.documentElement.scrollTop = 0;
// }
</script>
<!-- <script type="text/javascript">
$(".fancybox")
  .attr('rel', 'gallery')
  .fancybox({
      padding : 0
  });
</script> -->
        <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
        <script src="js/classie.js"></script>
        <script src="js/cbpAnimatedHeader.js"></script>

        <!-- Contact Form JavaScript -->
        <script src="js/jqBootstrapValidation.js"></script>
        <script src="js/contact_me.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/agency.js"></script>




    </body>
</html>
